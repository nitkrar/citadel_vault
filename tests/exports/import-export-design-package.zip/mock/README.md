# Import / Export Page — Design Package

## Contents

| File | Description |
|---|---|
| `import-export-mock.html` | Fully interactive HTML mock — open in any browser, no build step needed |
| `ImportExportPage.jsx` | Original source file provided for reference |
| `ImportModal.jsx` | Original modal source file provided for reference |
| `2026-04-04-export-field-visibility-design.md` | Claude-authored requirements brief that informed the redesign |
| `README.md` | This file |

---

## How to Preview the Mock

Open `import-export-mock.html` directly in a modern browser (Chrome, Firefox, Edge, Safari). No server, no dependencies, no build step required.

All interactions are live:

- **Import card** — click the drop zone, the Fetch button, or any template chip to open the import modal
- **Import modal** — steps through Upload → Review & Map → Importing (animated) → Done
- **Export card** — switch formats (JSON / CSV / XLSX / PDF) to see the Field Visibility section update; toggle Secrets on/off to trigger the plain-text warning; select/deselect entry type chips; click Export to see the loading state

---

## Design Decisions

### Layout: Side-by-Side (Current Mock) vs. Stacked

> **Note:** The current mock renders Import and Export as a **two-column side-by-side row**. The preferred direction discussed was a **stacked (top-bottom) layout** — Import above, Export below — which is the more natural reading order and avoids the two panels competing for attention at the same visual level.

The side-by-side layout was kept in the mock because it fits the existing app's card-grid pattern well on wider screens. When implementing, the layout can be switched to a single-column stack by changing the grid definition:

```css
/* Current — side by side */
.page-row {
  display: grid;
  grid-template-columns: 1fr 1.45fr;
  gap: 20px;
}

/* Preferred — stacked top to bottom */
.page-row {
  display: grid;
  grid-template-columns: 1fr;
  max-width: 680px;
  gap: 20px;
}
```

The stacked layout also makes the Import card naturally expand to full width, giving the drop zone, URL input, and template chips more breathing room — which suits the richer content added to the Import card.

---

## What Was Redesigned

### Import Card

The original Import card was a single button that opened a modal. The redesign surfaces all three entry points directly on the card so users understand the full capability before clicking anything:

1. **Drop zone** — primary affordance; drag-and-drop or click to browse
2. **Google Sheets URL input** — with a Fetch button, separated by an "or" divider
3. **Template download strip** — individual CSV buttons per entry type, plus an "All Types (Excel)" button

### Import Modal (2-step wizard)

The modal mirrors the card's upload options in a larger canvas, then proceeds to a column-mapping review step:

- **Step 1 — Upload:** Drop zone, Google Sheets URL, template downloads
- **Step 2 — Review & Map:** Sheet tabs (multi-sheet XLSX), entry type selector, column-mapping table with per-column dropdowns, unmapped-required-field warning
- **Importing:** Animated progress bar with encryption reassurance note
- **Done:** Success state with imported entry count

### Export Card — Field Visibility Toggles

The binary PDF "Overview / Full Detail" radio selector has been replaced with **per-field visibility toggles** that apply across CSV, XLSX, and PDF:

| Toggle | Applies to | Controls |
|---|---|---|
| Secrets | CSV, XLSX, PDF | Passwords, API keys, recovery keys, PINs |
| Monetary values | CSV, XLSX, PDF | Balances, prices, valuations, coverage amounts |
| Rates & quantities | CSV, XLSX, PDF | Interest rates, employer match, shares, quantities |
| Net worth summary | PDF only | Currency totals and portfolio valuation header |

**JSON is excluded** — it is the full-backup format and always exports everything. When JSON is selected, the Field Visibility section is hidden and replaced with an informational note.

**Secrets warning** — a red danger banner appears whenever the Secrets toggle is ON and the format is not JSON, reminding the user that passwords and keys will appear in plain text.

### Visual Consistency

All components use the same design tokens as the rest of the app:

- **Background:** `#0f1117` (page), `#141820` (cards), `#1a2030` (interactive surfaces)
- **Border:** `#1e2433`
- **Primary accent:** `#14b8a6` / `#2dd4bf` (teal)
- **Text:** `#f1f5f9` (primary), `#94a3b8` (secondary), `#64748b` (muted), `#475569` (labels)
- **Alerts:** Dark amber `#1c1a0e` / `#3d3210` for warnings; dark red `#1c0e0e` / `#3d1212` for danger
- **Buttons:** `#0d9488` primary, ghost with `#1e2433` border
- **Toggle switches:** Teal track when ON (`#0d9488`), neutral when OFF (`#1e2433`)

---

## Implementation Notes

- The Field Visibility state (`secrets`, `monetary`, `rates`, `networth`) should be passed into `exportJson` / `exportCsvZip` / `exportXlsx` / `exportPdf` as a `fieldVisibility` options object
- `pdfMode` state and `handlePdfModeChange` can be removed entirely
- The `PDF_MODES` constant can be deleted
- The Import card's drop zone and URL input are presentational in the mock — wire them to the existing `handleFileUpload` and `handleSheetUrl` handlers from `ImportModal.jsx`
- Template download chips call `downloadCsvTemplate(type)` and `downloadXlsxTemplateAll()` — already implemented in `ImportModal.jsx`
