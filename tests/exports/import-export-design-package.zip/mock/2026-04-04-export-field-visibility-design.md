# Export Field Visibility — Design Brief

## Context

Citadel Vault is a personal finance/password vault app. The Import/Export page (`src/client/pages/ImportExportPage.jsx` — already shared) lets users export their decrypted vault entries in JSON, CSV, XLSX, or PDF formats.

Currently, PDF has a binary "Overview vs Full Detail" mode selector that controls whether secrets and monetary fields appear. This is too blunt — users either get everything or a stripped-down summary. And CSV/XLSX have no field filtering at all, they always dump everything.

## What We Want

Replace the PDF mode selector (Overview/Full Detail) with **field visibility toggles** that apply across CSV, XLSX, and PDF. JSON is excluded — it's the full-backup format and should always export everything.

### The toggles (all ON by default):

| Toggle | What it controls |
|--------|-----------------|
| **Secrets** | Fields marked as `secret` type — passwords, API keys, recovery keys, PINs |
| **Monetary values** | Balances, prices, valuations — `balance`, `purchase_price`, `price_per_share`, `coverage_amount`, `cash_value`, `credit_limit`, `cost_price`, plus any number field with `portfolio_role: 'value'` or `'price'` |
| **Rates & quantities** | `interest_rate`, `employer_match`, `coupon_rate`, `shares`, `quantity` |
| **Net worth summary** | PDF only — the currency totals / portfolio valuation header section |

When a toggle is OFF, those fields are stripped from the export output.

### Conditional behavior:
- **JSON selected**: Field visibility section hidden entirely (JSON = full backup)
- **CSV/XLSX selected**: First 3 toggles shown
- **PDF selected**: All 4 toggles shown (includes Net worth summary)
- When Secrets is ON for a non-JSON format, show a red warning: secrets will be in plain text

## What's Changing on the Page

- **Remove**: `PDF_MODES` selector (Overview/Full Detail radio buttons), `pdfMode` state, `handlePdfModeChange`
- **Remove**: The conditional red "Full detail includes all secrets" warning (replaced by a secrets-toggle-aware version)
- **Add**: Field visibility toggles section inline on the page, between format selector and export button
- **Keep**: Everything else — entry type checkboxes, format pills, import section, warning banner, export button

## Balance We're Striking

The current page has import as a compact card with a modal, and export as a detailed inline section. We want to keep that asymmetry — export controls stay inline, no modal. But we're replacing a single binary radio (overview/full) with 3-4 small checkboxes, so the visual weight shouldn't change much. The field visibility section should feel like a natural part of the export flow, not a separate configuration area.

Each toggle needs a short description so users understand what "Monetary values" means without reading docs, but it shouldn't feel like a form — keep it lightweight.

## Technical Notes (for context, not prescriptive)

- The app uses a simple component library: cards, buttons (`btn-primary`, `btn-ghost`, `btn-sm`), checkboxes, CSS variables for theming
- Existing modal component exists at `src/client/components/Modal.jsx` but we're NOT using it here
- Mobile: columns stack, the page already handles responsive layout
- Dark mode is supported via CSS variables
